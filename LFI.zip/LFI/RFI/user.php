<?php
$output = shell_exec('whoami');
echo "<p>username:$output</p>";
?>

